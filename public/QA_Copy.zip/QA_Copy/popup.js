document.getElementById("copyBtn").addEventListener("click", async () => {
  const result = document.getElementById("result");

  try {
    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true,
    });

    const type = document.getElementById("type").value;

    const results = await chrome.scripting.executeScript({
      target: {
        tabId: tab.id,
      },

      func: (type) => {
        let items = Array.from(document.querySelectorAll(".tab-content .active a"))
          .map((a) => a.textContent.trim())
          .filter((text) => text.startsWith("ID:"));

        // 타입을 선택했다면 해당 타입만 필터링
        if (type) {
          items = items.filter((text) => text.includes(`타입:${type}`));
        }

        return items.join("\n");
      },

      args: [type],
    });

    const text = results[0].result;

    if (!text) {
      result.textContent = "조건에 맞는 ID가 없습니다.";
      return;
    }

    await navigator.clipboard.writeText(text);

    const count = text.split("\n").length;

    result.textContent = `${count}개 복사 완료!`;
  } catch (error) {
    console.error(error);
    result.textContent = "복사 실패";
  }
});
document.getElementById("DBcopyBtn").addEventListener("click", async () => {
  const result = document.getElementById("result");

  try {
    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true,
    });

    const type = document.getElementById("type").value;

    const results = await chrome.scripting.executeScript({
      target: {
        tabId: tab.id,
      },

      func: (type) => {
        let items = Array.from(
          document.querySelectorAll(".tab-content .active a"),
        )
          .map((a) => a.textContent.trim())
          .filter((text) => text.startsWith("ID:"));

        // 타입을 선택했다면 해당 타입만 필터링
        if (type) {
          items = items.filter((text) =>
            text.includes(`타입:${type}`),
          );
        }

        // ID와 타입 항목 제거
        items = items.map((text) =>
          text
            .split(",")
            .filter((item) => {
              const value = item.trim();

              return (
                !value.startsWith("ID:") &&
                !value.startsWith("타입:")
              );
            })
            .join(","),
        );

        return items.join("\n");
      },

      args: [type],
    });

    const text = results[0].result;

    if (!text) {
      result.textContent = "조건에 맞는 데이터가 없습니다.";
      return;
    }

    await navigator.clipboard.writeText(text);

    const count = text.split("\n").length;

    result.textContent = `${count}개 복사 완료!`;
  } catch (error) {
    console.error(error);
    result.textContent = "복사 실패";
  }
});